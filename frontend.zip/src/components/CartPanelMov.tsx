import React, { forwardRef, Ref } from 'react';
import { Trash2 } from 'lucide-react';

type CartItem = any;
type Partner = any;

const formatCurrency = (amount: number): string =>
  new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
  }).format(amount || 0);

const getNumericPrice = (item: CartItem): number => {
  if (typeof item.list_price === 'number' && item.list_price > 0) {
    return item.list_price;
  }
  if (typeof item.price === 'string') {
    const priceString = item.price.replace(/[$,\s]/g, '');
    const numericPrice = parseFloat(priceString);
    return isNaN(numericPrice) ? 0 : numericPrice;
  }
  if (typeof item.price === 'number') {
    return item.price;
  }
  return 0;
};

interface CartPanelMovProps {
  items: CartItem[];
  onRemove: (productId: number | string) => void;
  onQtyChange: (productId: number | string, newQty: number) => void;
  selectedPartner: Partner | null;
  onFinalizeOrder: () => void;
  isSubmitting: boolean;
}

export default forwardRef(function CartPanelMov(
  {
    items,
    onRemove,
    selectedPartner,
    onFinalizeOrder,
    isSubmitting,
    onQtyChange,
  }: CartPanelMovProps,
  ref: Ref<HTMLDivElement>
) {
  const subtotal = items.reduce(
    (sum, item) => sum + getNumericPrice(item) * item.qty,
    0
  );
  const taxes = 0;
  const homeDelivery = 0;
  const grandTotal = subtotal + taxes + homeDelivery;

  const CartItemRow: React.FC<any> = ({ item }) => (
    <div className="flex items-center py-1.5 border-b border-[#e3d6c7] last:border-b-0">
      {/* Mini imagen */}
      <div className="w-7 h-7 bg-gray-200 rounded-md flex-shrink-0 mr-2" />

      {/* Info */}
      <div className="flex-1 min-w-0">
        <p
          className="text-[11px] font-medium text-gray-800 truncate"
          title={item.name}
        >
          {item.name}
        </p>
        <p className="text-[10px] text-gray-600">
          {formatCurrency(getNumericPrice(item))} × {item.qty}
        </p>
      </div>

      {/* Controles */}
      <div className="flex items-center gap-1 ml-1">
        <div className="flex items-center border border-[#a89076] rounded-md bg-white">
          <button
            onClick={() => onQtyChange(item.id, item.qty - 1)}
            className="px-1 text-[11px] text-gray-700"
          >
            −
          </button>
          <span className="px-1 text-[11px] font-semibold">
            {item.qty}
          </span>
          <button
            onClick={() => onQtyChange(item.id, item.qty + 1)}
            className="px-1 text-[11px] text-gray-700"
          >
            +
          </button>
        </div>

        <button
          onClick={() => onRemove(item.id)}
          className="text-red-500 p-1 rounded-full hover:bg-red-50"
        >
          <Trash2 className="w-3 h-3" />
        </button>
      </div>
    </div>
  );

  return (
    <aside
      className="
        rounded-2xl shadow-md flex flex-col
        border border-[#a89076]
        bg-white
        p-2
        max-h-[360px]
        w-full
        max-w-[260px]   /* ✅ MÁS ANGOSTO */
      "
    >
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#e3d6c7] pb-1 mb-1">
        <h2 className="text-xs font-bold text-gray-900">
          Pedido ({items.length})
        </h2>
      </div>

      {/* Lista */}
      <div
        className="flex-1 overflow-y-auto pr-1 -mr-1"
        ref={ref}
      >
        {items.length === 0 ? (
          <div className="text-center py-4 text-[11px] text-gray-500">
            Carrito vacío
          </div>
        ) : (
          items.map((item) => (
            <CartItemRow key={item.id} item={item} />
          ))
        )}
      </div>

      {/* Totales */}
      <div className="mt-2 pt-2 border-t border-[#e3d6c7] text-[11px] space-y-1">
        <div className="flex justify-between">
          <span>Subtotal</span>
          <span>{formatCurrency(subtotal)}</span>
        </div>

        <div className="flex justify-between font-semibold text-[12px]">
          <span>Total</span>
          <span>{formatCurrency(grandTotal)}</span>
        </div>
      </div>

      {/* Acciones */}
      <div className="mt-2 flex flex-col gap-1">
        <button
          onClick={onFinalizeOrder}
          disabled={items.length === 0 || !selectedPartner || isSubmitting}
          className="
            w-full py-1.5 rounded-lg
            bg-[#a89076] text-white text-[11px] font-semibold
            disabled:bg-gray-300 disabled:text-gray-600
            transition hover:bg-[#967d63]
          "
        >
          {isSubmitting ? 'Procesando…' : 'Procesar'}
        </button>

        <button
          disabled={isSubmitting}
          className="
            w-full py-1.5 rounded-lg
            border border-red-300 text-red-600 text-[11px] font-semibold
            hover:bg-red-50 transition
          "
        >
          Devolver
        </button>
      </div>
    </aside>
  );
});
