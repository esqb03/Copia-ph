// src/components/HeaderMov.tsx
import React from 'react';
import { ShoppingCart, LogOut, Search, Menu } from 'lucide-react';

// 1. Definición de las Props del componente (Tipado)
interface HeaderMovProps {
    onLogout: () => void; // Función para manejar el cierre de sesión
    scrollToCart: () => void; // Función para desplazarse al panel del carrito
    scrollToSearch: () => void; // Función para desplazarse al campo de búsqueda
    cartItemCount: number; // Número de ítems únicos en el carrito
}

/**
 * Componente de encabezado superior. Diseñado principalmente para la navegación móvil.
 * Contiene el logo/título, el botón de búsqueda, el contador del carrito y el botón de logout.
 */
export default function HeaderMov({ 
    onLogout, 
    scrollToCart, 
    scrollToSearch, 
    cartItemCount 
}: HeaderMovProps) {

    return (
        // Fijo en la parte superior con un fondo para visibilidad.
        <header className="fixed top-0 left-0 right-0 z-40 bg-white shadow-lg p-4 transition-all duration-300">
            <div className="flex items-center justify-between max-w-7xl mx-auto">
                
                {/* 1. Logo/Título de la Aplicación */}
                <div className="flex items-center space-x-2">
                    <span className="font-extrabold text-xl text-blue-600">
                        OD<span className='text-gray-800'>OOSales</span>
                    </span>
                </div>
                
                {/* 2. Grupo de Botones de Acción */}
                <div className="flex items-center space-x-2 sm:space-x-4">
                    
                    {/* Botón de Búsqueda (útil en móvil para desplazarse al input) */}
                    <button 
                        onClick={scrollToSearch} 
                        className="p-2 rounded-full text-gray-700 hover:bg-gray-100 transition-colors hidden sm:block" // Ocultar en móvil si la búsqueda ya está visible
                        aria-label="Buscar productos"
                    >
                        <Search className="w-5 h-5" />
                    </button>

                    {/* Botón del Carrito con Contador */}
                    <button 
                        onClick={scrollToCart} 
                        className="relative p-2 rounded-full text-gray-700 hover:bg-gray-100 transition-colors"
                        aria-label={`Ver carrito. Ítems: ${cartItemCount}`}
                    >
                        <ShoppingCart className="w-6 h-6" />
                        
                        {/* Indicador de Ítems */}
                        {cartItemCount > 0 && (
                            <span className="absolute top-0 right-0 bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center border-2 border-white">
                                {cartItemCount > 9 ? '9+' : cartItemCount}
                            </span>
                        )}
                    </button>
                    
                    {/* Botón de Logout */}
                    <button 
                        onClick={onLogout} 
                        className="p-2 rounded-full text-red-600 hover:bg-red-50 transition-colors"
                        aria-label="Cerrar sesión"
                    >
                        <LogOut className="w-6 h-6" />
                    </button>
                    
                    {/* Botón de Menú (Ejemplo, si existiera un menú lateral) */}
                    {/* <button className="p-2 rounded-full text-gray-700 hover:bg-gray-100 transition-colors">
                        <Menu className="w-6 h-6" />
                    </button> */}
                </div>
            </div>
        </header>
    );
}
