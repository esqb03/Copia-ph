// src/components/ProductCard.tsx
import React from 'react';
import { Plus } from 'lucide-react';

interface ProductBase {
  id: number | string;
  name: string;
  list_price: number;
  price: number;
  image_512?: string;
  qty_available: number;
  default_code?: string;
}

interface ProductCardProps {
  product: ProductBase;
  onAdd: (product: ProductBase) => void;
}

export default function ProductCard({ product, onAdd }: ProductCardProps) {
  // Fallback seguro
  const hasValidImage =
    product.image_512 &&
    typeof product.image_512 === "string" &&
    product.image_512.trim().length > 20;

  const imageSrc = hasValidImage
    ? `data:image/png;base64,${product.image_512}`
    : "/app/default-image.png";

  const price =
    typeof product.list_price === "number" && product.list_price > 0
      ? product.list_price
      : product.price || 0;

  const formattedPrice = new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
  }).format(price);

  const stock = product.qty_available ?? 0;
  const outOfStock = stock <= 0;
  const lowStock = stock > 0 && stock <= 3;

  const buttonText = outOfStock
    ? "Sin stock"
    : lowStock
    ? "Últimas unidades"
    : "Añadir";

  return (
    <div
      className="
        rounded-lg 
        p-2 flex flex-col
        hover:shadow transition text-[9px] w-full

        border border-[#a89076]
        bg-[#faf6f1]        /* 👉 FONDO NUEVO */
      "
    >
      
      <div className="flex items-start justify-between gap-2">

        {/* INFO IZQUIERDA */}
        <div className="min-w-0">
          <p className="font-semibold text-gray-900 leading-tight line-clamp-1" title={product.name}>
            {product.name}
          </p>

          {product.default_code && (
            <p className="text-[8px] text-gray-500 uppercase">{product.default_code}</p>
          )}

          <p className="text-[10px] font-bold text-gray-900">{formattedPrice}</p>
        </div>

        {/* IMAGEN + STOCK */}
        <div className="flex flex-col items-center gap-1 flex-shrink-0">
          <div className="w-8 h-8 bg-white rounded overflow-hidden flex items-center justify-center border border-[#a89076]/40">
            <img
              src={imageSrc}
              alt={product.name}
              className="w-full h-full object-contain"
              onError={(e) => {
                e.currentTarget.onerror = null;
                e.currentTarget.src = "/default-image.png";
              }}
            />
          </div>

          <span
            className={`
              px-1.5 py-0.5 rounded-full text-[7px] font-semibold
              ${
                outOfStock
                  ? "bg-red-50 text-red-600"
                  : lowStock
                  ? "bg-yellow-50 text-yellow-700"
                  : "bg-emerald-50 text-emerald-600"
              }
            `}
          >
            {outOfStock ? "Sin stock" : `Stock: ${stock}`}
          </span>
        </div>
      </div>

      {/* BOTÓN BONITO */}
      <button
        onClick={() => !outOfStock && onAdd(product)}
        disabled={outOfStock}
        className={`
          mt-2 py-[3px] px-2 text-[9px]
          rounded-full font-medium
          flex items-center justify-center gap-1
          border border-[#a89076] 
          transition

          ${
            outOfStock
              ? "bg-gray-200 text-gray-400 cursor-not-allowed"
              : "bg-[#a89076] text-white hover:bg-[#967d63]"
          }
        `}
      >
        {!outOfStock && <Plus className="w-3 h-3" />}
        {buttonText}
      </button>

    </div>
  );
}



