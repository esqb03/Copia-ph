import React, { useState, useEffect, useCallback } from "react";
import { Search, RefreshCw } from "lucide-react";
import ProductCardMov from "./ProductCardMov";

const API_URL = import.meta.env.VITE_API_URL;

// ---------------- TIPOS ----------------
interface ProductBase {
  id: number | string;
  name: string;
  list_price: number;
  price: number;
  image_512?: string;
  qty_available: number;
  default_code?: string;
  description_sale?: string;
  [key: string]: any;
}

interface ModalState {
  isOpen: boolean;
  title: string;
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
  confirmText: string;
  isDanger: boolean;
  showCancel: boolean;
}

interface ProductSearchCardProps {
  onAdd: (product: ProductBase) => void;
  setModalState: React.Dispatch<React.SetStateAction<ModalState>>;
}

export default function ProductSearchCardMov({ onAdd }: ProductSearchCardProps) {
  const [products, setProducts] = useState<ProductBase[]>([]);
  const [filtered, setFiltered] = useState<ProductBase[]>([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // -------------------- FILTRO --------------------
  useEffect(() => {
    if (query.trim() === "") {
      setFiltered(products);
      return;
    }

    const q = query.toLowerCase();
    const filteredProducts = products.filter(
      (p) =>
        (p.name || "").toLowerCase().includes(q) ||
        ((p.default_code || "").toLowerCase().includes(q))
    );

    setFiltered(filteredProducts);
  }, [query, products]);

  // -------------------- FETCH --------------------
  const fetchProducts = useCallback(async () => {
    setLoading(true);
    setError(null);

    const employeeId = localStorage.getItem("employee_id");
    if (!employeeId) {
      setError("ID de empleado no encontrado. Inicie sesión nuevamente.");
      setLoading(false);
      return;
    }

    try {
      const response = await fetch(
        `${API_URL}/products?employee_id=${employeeId}&limit=100`
      );

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({
          message: "Error al obtener productos.",
        }));
        throw new Error(
          errorData.detailedError ||
            errorData.message ||
            `Error HTTP: ${response.status}`
        );
      }

      const result = await response.json();

      if (Array.isArray(result)) {
        setProducts(result);
        setFiltered(result);
      } else {
        throw new Error("Formato de respuesta de productos inválido.");
      }
    } catch (err: any) {
      console.error("Error al cargar productos:", err);
      setError(err.message || "Fallo la conexión con el servidor.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  // -------------------- UI --------------------
  return (
    <div
      className="
        flex flex-col
        h-full w-full max-w-full min-w-0
        overflow-hidden
        bg-white
        rounded-none
        shadow-none
        p-2
      "
    >
      {/* Header + Search */}
      <div className="mb-2 flex-shrink-0 min-w-0">
  

        <div className="relative min-w-0">
          <input
            type="text"
            placeholder="Buscar..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="
              w-full max-w-full min-w-0
              p-2 pl-8 rounded-lg
              bg-gray-50
              border border-gray-200
              text-[12px] text-gray-800
              placeholder:text-gray-500
              focus:border-[#a89076]
              focus:ring-1 focus:ring-[#a89076]
              transition
            "
            disabled={loading}
          />
          <Search className="w-4 h-4 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
        </div>
      </div>

      {/* Estados */}
      {loading && (
        <div className="text-center p-2 text-[#a89076] text-[11px] flex items-center justify-center">
          <RefreshCw className="w-4 h-4 animate-spin mr-2" />
          Cargando...
        </div>
      )}

      {error && (
        <div className="text-center p-2 text-[11px] text-red-600 bg-red-50 rounded-lg">
          Error: {error}
          <button
            onClick={fetchProducts}
            className="ml-2 text-[#a89076] font-semibold hover:underline"
          >
            Reintentar
          </button>
        </div>
      )}

      {/* Lista */}
      <div className="flex-1 min-w-0 w-full max-w-full overflow-y-auto overflow-x-hidden pt-1 px-1">
        {filtered.length === 0 && !loading && !error ? (
          <div className="text-center text-gray-500 p-2 text-[11px]">
            {query.trim() !== ""
              ? `No hay resultados para "${query}".`
              : "No hay productos disponibles."}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-2 w-full max-w-full min-w-0">
            {filtered.map((product) => (
              <div key={product.id} className="min-w-0 max-w-full">
                <ProductCardMov product={product} onAdd={onAdd} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
