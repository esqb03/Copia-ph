import React, { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface LoginPageProps {
  onLogin: () => void;
}

export default function LoginPage({ onLogin }: LoginPageProps) {
  const [email, setEmail] = useState('argenistellis@gmail.com');
  const [password, setPassword] = useState('123456');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
  };

  return (
    <div className="w-full max-w-md bg-white rounded-2xl shadow-lg p-8">
      <h1 className="text-3xl font-semibold mb-8 text-gray-800">
        Bienvenidos!
      </h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block mb-2 text-sm text-gray-700">
            Correo electrónico
          </label>
          <input
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            className="w-full px-4 py-3 bg-[#fff9c7] border border-[#e8e4db] rounded-lg focus:outline-none focus:border-[#a89076]"
          />
        </div>

        <div>
          <label className="block mb-2 text-sm text-gray-700">
            Contraseña
          </label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full px-4 py-3 bg-[#fff9c7] border border-[#e8e4db] rounded-lg focus:outline-none focus:border-[#a89076]"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
            >
              {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          </div>
        </div>

        <div className="text-right">
          <a href="#" className="text-gray-500 text-sm hover:text-[#a89076]">
            ¿Olvidaste tu contraseña?
          </a>
        </div>

        <button
          type="submit"
          className="w-full bg-[#a89076] hover:bg-[#967d63] text-white py-3 rounded-lg flex items-center justify-center gap-3 transition-colors"
        >
          Sign in
        </button>
      </form>

      <p className="mt-8 text-center text-gray-600 text-sm">
        ¿No tienes una cuenta?{' '}
        <a href="#" className="text-[#a89076] hover:underline">
          Crear cuenta
        </a>
      </p>
    </div>
  );
}


