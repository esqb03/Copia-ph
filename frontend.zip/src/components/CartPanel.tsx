// src/components/CartPanel.tsx
import React, { forwardRef, Ref } from 'react';
import { Trash2 } from 'lucide-react';

type CartItem = any;
type Partner = any;

const formatCurrency = (amount: number): string =>
  new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
  }).format(amount || 0);

const getNumericPrice = (item: CartItem): number => {
  if (typeof item.list_price === 'number' && item.list_price > 0) {
    return item.list_price;
  }
  if (typeof item.price === 'string') {
    const priceString = item.price.replace(/[$,\s]/g, '');
    const numericPrice = parseFloat(priceString);
    return isNaN(numericPrice) ? 0 : numericPrice;
  }
  if (typeof item.price === 'number') {
    return item.price;
  }
  return 0;
};

interface CartPanelProps {
  items: CartItem[];
  onRemove: (productId: number | string) => void;
  onQtyChange: (productId: number | string, newQty: number) => void;
  selectedPartner: Partner | null;
  onFinalizeOrder: () => void;
  isSubmitting: boolean;
}

export default forwardRef(function CartPanel(
  {
    items,
    onRemove,
    selectedPartner,
    onFinalizeOrder,
    isSubmitting,
    onQtyChange,
  }: CartPanelProps,
  ref: Ref<HTMLDivElement>
) {
  const subtotal = items.reduce(
    (sum, item) => sum + getNumericPrice(item) * item.qty,
    0
  );
  const taxes = 0;
  const homeDelivery = 0;
  const grandTotal = subtotal + taxes + homeDelivery;

  const CartItemRow: React.FC<any> = ({ item, onRemove, onQtyChange }) => (
    <div className="flex items-center py-2 border-b border-[#e3d6c7] last:border-b-0">
      <div className="w-9 h-9 bg-gray-200 rounded-md flex-shrink-0 mr-2" />

      <div className="flex-1 min-w-0">
        <div
          className="text-xs font-medium text-gray-800 truncate"
          title={item.name}
        >
          {item.name}
        </div>
        <div className="text-[11px] text-gray-600">
          {formatCurrency(getNumericPrice(item))} x {item.qty}
        </div>
      </div>

      <div className="flex items-center gap-2 ml-2">
        <div className="flex items-center border border-[#a89076] rounded-md bg-white">
          <button
            onClick={() => onQtyChange(item.id, item.qty - 1)}
            className="px-1 text-gray-700 hover:bg-gray-200 rounded-l-md text-xs"
          >
            -
          </button>
          <span className="px-2 text-xs font-semibold text-gray-800">
            {item.qty}
          </span>
          <button
            onClick={() => onQtyChange(item.id, item.qty + 1)}
            className="px-1 text-gray-700 hover:bg-gray-200 rounded-r-md text-xs"
          >
            +
          </button>
        </div>

        <span className="font-semibold text-xs text-neutral-900 w-16 text-right flex-shrink-0">
          {formatCurrency(getNumericPrice(item) * item.qty)}
        </span>

        <button
          onClick={() => onRemove(item.id)}
          className="text-red-500 hover:text-red-700 p-1 rounded-full hover:bg-red-50 transition ml-1"
        >
          <Trash2 className="w-3 h-3" />
        </button>
      </div>
    </div>
  );

  return (
    <aside
      className="
        rounded-xl shadow-md flex flex-col
        border border-[#a89076]
        bg-white           /* 👉 fondo blanco-gris bien marcado */
        p-3
        max-h-[460px]
      "
    >
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#e3d6c7] pb-2 mb-2 flex-shrink-0">
        <h2 className="text-sm font-bold text-gray-900">
          Orden de Pedido de Venta ({items.length})
        </h2>
      </div>

      {/* Lista con scroll */}
      <div
        className="flex-1 overflow-y-auto pr-2 -mr-2 text-xs"
        ref={ref}
      >
        {items.length === 0 ? (
          <div className="text-center py-6 text-gray-500 text-xs">
            El carrito está vacío.
          </div>
        ) : (
          <div>
            {items.map((item) => (
              <CartItemRow
                key={item.id}
                item={item}
                onRemove={onRemove}
                onQtyChange={onQtyChange}
              />
            ))}
          </div>
        )}
      </div>

      {/* Totales */}
      <div className="mt-3 pt-3 border-t border-[#e3d6c7] flex flex-col gap-1 flex-shrink-0 text-xs">
        <div className="flex items-center justify-between text-gray-700">
          <span>Subtotal</span>
          <span>{formatCurrency(subtotal)}</span>
        </div>

        <div className="flex items-center justify-between text-gray-700">
          <span>Impuestos (0%)</span>
          <span>{formatCurrency(taxes)}</span>
        </div>

        <div className="flex items-center justify-between text-gray-700">
          <span>Envío</span>
          <div className="flex items-center gap-2">
            <span className="font-semibold">
              {formatCurrency(homeDelivery)}
            </span>
            <div className="w-4 h-4 bg-[#d8c5ae] rounded-full cursor-pointer" />
          </div>
        </div>

        <div className="flex items-center justify-between text-sm font-bold pt-1 text-neutral-900">
          <span>TOTAL</span>
          <span>{formatCurrency(grandTotal)}</span>
        </div>
      </div>

      {/* Acciones */}
      <div className="mt-4 flex gap-2 flex-shrink-0">
        <button
          onClick={onFinalizeOrder}
          disabled={items.length === 0 || !selectedPartner || isSubmitting}
          className="
            flex-1 py-2 rounded-lg
            bg-[#a89076] text-white text-xs font-semibold
            disabled:bg-gray-300 disabled:text-gray-600
            transition hover:bg-[#967d63]
          "
        >
          {isSubmitting ? 'Creando Orden...' : 'Procesar Pedido'}
        </button>

        <button
          disabled={isSubmitting}
          className="
            flex-1 py-2 rounded-lg
            border border-red-300 text-red-600 text-xs font-semibold
            hover:bg-red-50 transition
          "
        >
          Devolver Orden
        </button>
      </div>
    </aside>
  );
});


