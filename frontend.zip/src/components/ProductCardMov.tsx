import React, { useMemo, useRef } from "react";
import { Plus, Package, DollarSign } from "lucide-react";

interface ProductBase {
  id: number | string;
  name: string;
  list_price: number;
  price: number;
  image_512?: string;
  qty_available: number;
  default_code?: string;
}

interface ProductCardProps {
  product: ProductBase;
  onAdd: (product: ProductBase) => void;
}

function resolveImageSrc(image_512?: string) {
  if (!image_512 || typeof image_512 !== "string") return "/default-image.png";
  const trimmed = image_512.trim();
  if (trimmed.length < 20) return "/default-image.png";
  if (trimmed.startsWith("data:image/")) return trimmed;
  return `data:image/png;base64,${trimmed}`;
}

export default function ProductCardMov({ product, onAdd }: ProductCardProps) {
  const imgErroredRef = useRef(false);
  const imageSrc = useMemo(() => resolveImageSrc(product.image_512), [product.image_512]);

  const price = useMemo(() => {
    const lp = Number(product.list_price);
    const p = Number(product.price);
    return (Number.isFinite(lp) && lp > 0) ? lp : (Number.isFinite(p) && p > 0 ? p : 0);
  }, [product.list_price, product.price]);

  const formattedPrice = useMemo(() => {
    return new Intl.NumberFormat("es-CO", {
      style: "currency",
      currency: "COP",
      minimumFractionDigits: 0,
    }).format(price);
  }, [price]);

  const outOfStock = product.qty_available <= 0;

  return (
    <div className="bg-white p-3 rounded-lg shadow-sm border border-gray-100 flex flex-col w-full overflow-hidden">
      
      {/* Encabezado */}
      <div className="flex justify-between items-center mb-2 border-b border-gray-50 pb-1">
        <span className="text-[10px] font-bold text-[#a89076]">
          #{product.default_code || 'S/N'}
        </span>
        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${outOfStock ? 'bg-red-50 text-red-400' : 'bg-green-50 text-green-600'}`}>
          {outOfStock ? 'Agotado' : 'Disponible'}
        </span>
      </div>

      {/* Área Central: Layout horizontal */}
      <div className="flex items-center gap-3">
        
        {/* CONTENEDOR TRANSPARENTE (Mantiene la estructura sin verse) */}
        <div className="w-12 h-12 flex-shrink-0 bg-transparent flex items-center justify-center overflow-hidden">
          <img
            src={imageSrc}
            alt={product.name}
            className={`w-full h-full object-contain mix-blend-multiply ${
                outOfStock ? 'grayscale opacity-30' : ''
            }`}
            style={{ 
              maxWidth: '44px', 
              maxHeight: '44px',
              display: 'block' 
            }}
            onError={(e) => {
              if (!imgErroredRef.current) {
                imgErroredRef.current = true;
                e.currentTarget.src = "/default-image.png";
              }
            }}
          />
        </div>

        {/* Info del producto */}
        <div className="flex-1 min-w-0">
          <p className="text-[11px] font-bold text-gray-800 line-clamp-2 leading-tight mb-0.5">
            {product.name}
          </p>
          <p className="text-sm font-black text-green-700">
            {formattedPrice}
          </p>
          <div className="flex items-center gap-1 text-[9px] text-gray-400">
             <Package size={10} />
             <span>Cantidad en Stock: {product.qty_available}</span>
          </div>
        </div>
      </div>

      {/* Fila de Acción (Estilo OrderCard con icono +) */}
      <div className="mt-2 pt-2 border-t border-dashed border-gray-100 flex justify-end">
        <button
          type="button"
          onClick={() => !outOfStock && onAdd(product)}
          disabled={outOfStock}
          className={`p-1.5 rounded-full transition-all duration-200 ${
            outOfStock 
              ? 'text-gray-200 cursor-not-allowed' 
              : 'text-gray-400 hover:text-[#a89076] hover:bg-[#faf6f1] active:scale-90'
          }`}
        >
          <Plus size={20} strokeWidth={2.5} />
        </button>
      </div>
    </div>
  );
}