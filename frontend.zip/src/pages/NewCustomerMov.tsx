import React, { useState, useEffect } from 'react';
import { User, Mail, Phone, MapPin, Save, RefreshCw, ChevronLeft, ChevronDown, Building2, Map } from 'lucide-react';

const API_URL = import.meta.env.VITE_API_URL;

interface FormData {
    name: string; email: string; phone: string;
    street: string; city: string; zip: string; country_id: number; 
}
interface Country { id: number; name: string; }
interface MessageState { text: string; type: 'success' | 'error' | ''; }
interface NewCustomerMovProps { onBack: () => void; }

export default function NewCustomerMov({ onBack }: NewCustomerMovProps) {
    const [formData, setFormData] = useState<FormData>({
        name: '', email: '', phone: '', street: '', city: 'Medellín', zip: '050001', country_id: 0, 
    });
    const [countries, setCountries] = useState<Country[]>([]);
    const [isSaving, setIsSaving] = useState(false);
    const [message, setMessage] = useState<MessageState>({ text: '', type: '' });

    useEffect(() => {
        const fetchCountries = async () => {
            try {
                const res = await fetch(`${API_URL}/countries`);
                const data = await res.json();
                setCountries(data);
                const col = data.find((c: Country) => c.name.toLowerCase() === 'colombia');
                if (col) setFormData(p => ({ ...p, country_id: col.id }));
            } catch (e) { console.error(e); }
        };
        fetchCountries();
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const eid = localStorage.getItem('employee_id');
        if (!eid || !formData.name || !formData.email) {
             setMessage({ text: 'Nombre y Email requeridos.', type: 'error' }); return;
        }
        setIsSaving(true);
        try {
            const res = await fetch(`${API_URL}/register-partner`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ...formData, employee_id: eid }),
            });
            if (res.ok) {
                setMessage({ text: 'Cliente creado correctamente.', type: 'success' });
                setTimeout(onBack, 1500);
            } else {
                setMessage({ text: 'Error al guardar.', type: 'error' });
            }
        } catch { setMessage({ text: 'Error de conexión.', type: 'error' }); }
        finally { setIsSaving(false); }
    };

    const InputField = ({ icon: Icon, label, ...props }: any) => (
        <div className="relative group">
            <label className="text-xs font-semibold text-gray-500 mb-2 ml-1 block uppercase tracking-wider">
                {label}
            </label>
            <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none z-10">
                    <Icon size={20} className="text-gray-400 group-focus-within:text-[#a89076] transition-colors" />
                </div>
                <input
                    {...props}
                    className="
                        w-full h-14 pl-12 pr-4 
                        bg-gray-50 border border-gray-100
                        rounded-xl text-gray-900 placeholder-gray-400 font-medium
                        focus:bg-white focus:border-[#a89076] focus:ring-2 focus:ring-[#a89076]/20 focus:outline-none
                        transition-all duration-200 ease-in-out
                    "
                />
            </div>
        </div>
    );

    return (
        <div className="min-h-screen bg-[#f8f9fa]">
            <header className="sticky top-0 z-20 bg-white px-4 h-16 flex items-center border-b border-gray-200 shadow-sm">
                <button onClick={onBack} className="p-2 -ml-2 text-gray-600 hover:text-black rounded-full hover:bg-gray-100 transition-colors">
                    <ChevronLeft size={28} />
                </button>
                <h1 className="ml-3 text-xl font-bold text-gray-800">Nuevo Cliente</h1>
            </header>

            <main className="p-4 pb-32 max-w-lg mx-auto">
                <form onSubmit={handleSubmit} className="space-y-6">
                    
                    <section className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-5">
                        <h2 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4">Información Personal</h2>
                        <InputField 
                            icon={User} label="Nombre Completo" name="name" 
                            placeholder="Ej. Carlos Rodriguez" value={formData.name} 
                            onChange={(e: any) => setFormData({...formData, name: e.target.value})} 
                        />
                        <InputField 
                            icon={Mail} label="Correo Electrónico" name="email" type="email"
                            placeholder="cliente@ejemplo.com" value={formData.email} 
                            onChange={(e: any) => setFormData({...formData, email: e.target.value})} 
                        />
                        <InputField 
                            icon={Phone} label="Teléfono" name="phone" type="tel"
                            placeholder="300 123 4567" value={formData.phone} 
                            onChange={(e: any) => setFormData({...formData, phone: e.target.value})} 
                        />
                    </section>

                    <section className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-5">
                        <h2 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4">Ubicación</h2>
                        
                        <div className="relative group">
                            <label className="text-xs font-semibold text-gray-500 mb-2 ml-1 block uppercase tracking-wider">País</label>
                            <div className="relative">
                                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none z-10">
                                    <Map size={20} className="text-gray-400 group-focus-within:text-[#a89076]" />
                                </div>
                                <select
                                    className="w-full h-14 pl-12 pr-10 appearance-none bg-gray-50 border border-gray-100 rounded-xl text-gray-900 font-medium focus:bg-white focus:border-[#a89076] focus:ring-2 focus:ring-[#a89076]/20 focus:outline-none transition-all"
                                    value={formData.country_id}
                                    onChange={(e) => setFormData({...formData, country_id: parseInt(e.target.value)})}
                                >
                                    <option value={0}>Seleccionar...</option>
                                    {countries.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                </select>
                                <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none text-gray-400">
                                    <ChevronDown size={20} />
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <InputField 
                                icon={Building2} label="Ciudad" name="city" 
                                placeholder="Ciudad" value={formData.city} 
                                onChange={(e: any) => setFormData({...formData, city: e.target.value})} 
                            />
                            <InputField 
                                icon={MapPin} label="Dirección" name="street" 
                                placeholder="Calle 10 #20" value={formData.street} 
                                onChange={(e: any) => setFormData({...formData, street: e.target.value})} 
                            />
                        </div>
                    </section>

                    {message.text && (
                        <div className={`p-4 rounded-xl text-sm font-medium text-center ${
                            message.type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-600 border border-red-200'
                        }`}>
                            {message.text}
                        </div>
                    )}

                    <div className="pt-4">
                        <button
                            type="submit"
                            disabled={isSaving}
                            className="
                                w-full h-14 rounded-2xl
                                bg-[#a89076] hover:bg-[#967d63] text-white font-bold text-lg
                                shadow-lg shadow-[#a89076]/30 active:scale-[0.98] transition-all
                                flex items-center justify-center gap-2
                            "
                        >
                            {isSaving ? <RefreshCw className="animate-spin" /> : <Save size={24} />}
                            <span>{isSaving ? 'Guardando...' : 'Guardar Cliente'}</span>
                        </button>
                    </div>
                </form>
            </main>
        </div>
    );
}